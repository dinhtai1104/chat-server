/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Admin
 */
public enum ConnectionType {
    LOGIN,
    REPLY_LOGIN,
    REGISTER,
    REPLY_REGISTER,
    CHAT,
    GETCHAT,
    REPLY_CHAT,
    CREATEROOM,
    REPLY_CREATEROOM,
    GETFRIEND,
    REPLY_GETFRIEND,
    FRIENDREQUEST,
    REPLY_FRIENDREQUEST,
    GETROOM,
    REPLY_GETROOM,
    ONLINE_INFORM,
    OFFLINE_INFORM,
    ADDFRIEND,
    REPLY_ADDFRIEND,
    DECLINEFRIEND,
    REPLY_DECLINEFRIEND,
    INVITEROOM,
    REPLY_INVITEROOM,
    GETROOMFRIEND,
    REPLY_GETROOMFRIEND,
    GETFRIENDREQUEST,
    REPLY_GETFRIENDREQUEST,
    SEARCH,
    REPLY_SEARCH,
    EDITPROFILE,
    REPLY_EDITPROFILE
}
